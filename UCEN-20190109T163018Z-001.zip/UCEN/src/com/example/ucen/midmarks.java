package com.example.ucen;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class midmarks extends ActionBarActivity {
	EditText rno;
	public static String srno;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.midmarks);
        rno = (EditText)findViewById(R.id.editText2);
        
    }
   

    public void midpage (View view){
    	srno=rno.getText().toString();

        
        if((srno).length()==0)
        {
        	Toast t=Toast.makeText(getApplicationContext(),"Enter Roll Number", Toast.LENGTH_SHORT);
        	t.show();
        }

        else 
        {
        
        
        	Intent i=new Intent(this,midmarkspage.class);
        	startActivity(i);
        }
        }

}
