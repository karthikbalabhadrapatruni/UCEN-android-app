package com.example.ucen;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;



public class attendance extends Activity {
	public EditText rno;
	public static String srno;

	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.attendance);
        
        rno=(EditText)findViewById(R.id.editText);
        
    }
  

    public void attend (View view){
    	srno=rno.getText().toString();

    	if((srno).length()!=0){
    		
        	startActivity(new Intent(this,aattendancepage.class));
    	}
    	else{
    		Toast t=Toast.makeText(getApplicationContext(),"Enter Roll Number", Toast.LENGTH_SHORT);
        	t.show();
    	}
       
    }
}



