package com.example.ucen;



import android.support.v7.app.ActionBarActivity;

import android.content.Intent;
import android.os.Bundle;

import android.view.View;



public class MainActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

    }
    public void attendance(View view){
    	
    	Intent i=new Intent(this,attendance.class);
    	startActivity(i);
    }
    
    public void mid(View view){
    	Intent i=new Intent(this,midmarks.class);
    	startActivity(i);
    	
    }
}