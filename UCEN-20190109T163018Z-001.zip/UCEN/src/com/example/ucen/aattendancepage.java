package com.example.ucen;


 




import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

import com.mysql.jdbc.Connection;


import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;





public class aattendancepage extends attendance{
	
	
	 
	TextView rollno ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.attendancepage);
        rollno= (TextView)findViewById(R.id.textView1);
        
        new backtask().execute();
        
        
    }
    private class backtask extends AsyncTask<Void,Void,Integer>{
    	
        		
				@Override
				protected void onPreExecute(){
					rollno.setText(srno);
				}
				
				@Override
				protected Integer doInBackground(Void... params) {
					try{
	        			Class.forName("com.mysql.jdbc.Driver");
	        			Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://10.0.2.2:3306/chtgion","root","2655");
	        			Statement stmt=con.createStatement();
	        			ResultSet rs=stmt.executeQuery("SELECT * FROM user_info WHERE userid ='"+srno+"'");
	        			ResultSetMetaData rmd=rs.getMetaData();
	        			for (int i=1;i<=rmd.getColumnCount();i++){
	        				System.out.print(rmd.getColumnName(i)+"\t");
	        			}
	        			System.out.println("");
	        		    while(rs.next()){
	        		    	for(int i=1;i<=rmd.getColumnCount();i++){
	        		    	 System.out.print(rs.getString(i)+"\t");	
	        		    	}
	        		    }
	        	        
	        		    if(!rs.absolute(1)){
	        		    	System.out.print("not found");
	        		    	return 0;
	        		    }
	        			
	        			con.close();
	        	
	        		}catch(Exception e){
	        			System.out.print(e);
	        			
	        			return -1;
	        		}
					return 3;
					
				}
				@Override
				protected void onPostExecute(Integer i){
					
			        if(i==0){
			        	rollno.setText("NOT A VALID NUMBER");
			        }
			        if(i==-1){

	        			rollno.setText("UNABLE TO CONNECT SERVER");
			        }
			        
				}
        	}
        
        
     
    }
